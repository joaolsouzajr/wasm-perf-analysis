# WebAssembly: Um Estudo Quantitativo dePerformance
João Lourenço Souza Jr

Estrutura de arquivos:

* ./data - Diretorio com resultado dos testes
* wasm_analise_resultados.ipynb -  Arquivo com código utilizado na analise do resultado.


Dependências:

* juoyter-notebook
* numpy
* pandas
* matplotlib

Repositorio de código GIT: https://github.com/joaolsouzajr/wasm-perf-analysis